<template>
    <section class="about">
        <h2>This is an about page</h2>
    </section>
</template>

<style scoped>
.about {
    height: 20rem;
}
</style>